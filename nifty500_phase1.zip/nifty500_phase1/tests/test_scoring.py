from src.analysis.scoring import score_stock


def test_scoring_bounds():
    tech = {'trend':'Bullish','rsi':55,'macd':2,'macd_signal':1,'setup':'Pullback','rel_volume':1.5,'atr':1.5,'close':100}
    score = score_stock({'roce':20,'roe':15,'sales_growth':20,'profit_growth':25,'debt_equity':0.5}, tech, {'mos_pct':20})
    assert 0 <= score['composite'] <= 100
    assert score['technical'] >= 0


def test_missing_fundamentals_not_fabricated():
    tech = {'trend':'Mixed','rsi':50,'macd':0,'macd_signal':1,'setup':'No setup','rel_volume':1,'atr':2,'close':100}
    result = score_stock({}, tech, {'fair_value':None,'mos_pct':None})
    assert result['fundamental'] == 0
    assert result['valuation'] == 0
    assert result['confidence'] == 0
